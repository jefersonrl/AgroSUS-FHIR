# Resultados Laboratoriais AgroSUS - Módulo AgroSUS — Projeto mareIA v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Resultados Laboratoriais AgroSUS**

## ValueSet: Resultados Laboratoriais AgroSUS 

| | |
| :--- | :--- |
| *Official URL*:https://jefersonrl.github.io/AgroSUS-FHIR/ValueSet/agrosus-resultados-laboratoriais | *Version*:0.1.0 |
| Draft as of 2026-07-21 | *Computable Name*:AgroSUSResultadosLaboratoriaisVS |

 
Biomarcadores laboratoriais utilizados no acompanhamento assistencial dos trabalhadores rurais no AgroSUS. 

 **References** 

* [Resultado Laboratorial AgroSUS](StructureDefinition-agrosus-resultado-laboratorial.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "agrosus-resultados-laboratoriais",
  "url" : "https://jefersonrl.github.io/AgroSUS-FHIR/ValueSet/agrosus-resultados-laboratoriais",
  "version" : "0.1.0",
  "name" : "AgroSUSResultadosLaboratoriaisVS",
  "title" : "Resultados Laboratoriais AgroSUS",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-21T03:04:10+00:00",
  "publisher" : "Fatec Ferraz de Vasconcelos",
  "contact" : [{
    "name" : "Fatec Ferraz de Vasconcelos",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.fatecferraz.edu.br"
    }]
  }],
  "description" : "Biomarcadores laboratoriais utilizados no acompanhamento assistencial dos trabalhadores rurais no AgroSUS.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR",
      "display" : "Brazil"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "718-7"
      },
      {
        "code" : "4544-3"
      },
      {
        "code" : "6690-2"
      },
      {
        "code" : "777-3"
      },
      {
        "code" : "1920-8"
      },
      {
        "code" : "1742-6"
      },
      {
        "code" : "2324-2"
      },
      {
        "code" : "6768-6"
      },
      {
        "code" : "1751-7"
      },
      {
        "code" : "2160-0"
      },
      {
        "code" : "3091-6"
      },
      {
        "code" : "14959-1"
      },
      {
        "code" : "1558-6"
      },
      {
        "code" : "2099-0"
      },
      {
        "code" : "2098-2"
      },
      {
        "code" : "6301-6"
      }]
    }]
  }
}

```
