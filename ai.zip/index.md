# Início - Projeto mareIA: módulo AgroSUS para telemonitoramento e apoio à identificação precoce de intoxicações por uso de defensivos agrícolas v0.1.0

* [**Table of Contents**](toc.md)
* **Início**

## Início

| | |
| :--- | :--- |
| *Official URL*:https://jefersonrl.github.io/AgroSUS-FHIR/ImplementationGuide/io.github.jefersonrl.agrosus | *Version*:0.1.0 |
| Draft as of 2026-07-21 | *Computable Name*:AgroSUSFHIR |

 Este Implementation Guide e seus artefatos estão em desenvolvimento (`draft`). 

 Conteúdo para fins de demonstração e implementação piloto. 

### Projeto mareIA — AgroSUS

Adaptação digital (WHO SMART Guidelines **L2/L3**) para o pathway **AgroSUS** da Plataforma mareIA — telemonitoramento e apoio à identificação precoce de **intoxicação por defensivos agrícolas** em trabalhadores rurais, na Atenção Primária à Saúde, com vigilância biológica pela **colinesterase sanguínea** (NR-7) e boas práticas de segurança no trabalho rural (NR-31).

> Este IG cobre **apenas o pathway AgroSUS**. No SMART Guidelines, cada linha de cuidado da Plataforma mareIA é um IG independente — ver ADR-0003 (`docs/adr/`) sobre a disciplina de documentação adotada.

#### Fluxo de cuidado (4 macrofases)

`Cadastro → Triagem ocupacional (anamnese) → Resposta clínica e vigilância biológica → Acompanhamento longitudinal`

1. **Cadastro**— identificação do trabalhador rural pelo ACS, cadastro do trabalhador e da propriedade rural.
1. **Triagem ocupacional**— aplicação da anamnese ocupacional/ambiental (18 seções) em visita domiciliar, sincronizada de forma atômica e offline-first.
1. **Resposta clínica e vigilância biológica**— avaliação na UBS, monitoramento da colinesterase (periodicidade semestral mínima, NR-7), registro da condição clínica quando aplicável.
1. **Acompanhamento longitudinal**— plano de acompanhamento com periodicidade de reavaliação, proveniência e auditoria de todos os registros.

#### Componentes do DAK (L2)

| | | |
| :--- | :--- | :--- |
| 1 | Intervenções e recomendações | [l2-interventions](l2-interventions.md) |
| 2 | Personas genéricas | [l2-personas](l2-personas.md) |
| 3 | Cenários de uso | [l2-user-scenarios](l2-user-scenarios.md) |
| 4 | Processos de negócio e workflows | [l2-business-process](l2-business-process.md) |
| 5 | Elementos de dados (dicionário) | [l2-data-dictionary](l2-data-dictionary.md) |
| 6 | Lógica de suporte à decisão | [l2-decision-logic](l2-decision-logic.md) |
| 7 | Indicadores de programa | [l2-indicators](l2-indicators.md) |
| 8 | Requisitos | [l2-requirements](l2-requirements.md) |
| 9 | Cenários de teste | [l2-test-scenarios](l2-test-scenarios.md) |

#### Itens pendentes de confirmação clínica

* **Escore de risco ocupacional** — não há, em NR-7/NR-31, um instrumento composto de risco validado (`docs/adr/0002-escore-risco-nao-definido.md`).

**Fonte (L1): NR-7 (PCMSO), NR-31 (Segurança e Saúde no Trabalho Rural) e Nota Informativa nº 16/2019-CGLAB/DAEVS/SVS/MS — Ministério da Saúde. Ver `sources/_normas_extract.txt`.**

* Para a lista completa de artefatos definidos neste IG, ver o [Artifact Index](artifacts.md).
* Uma cópia offline completa deste IG está disponível na página de [Downloads](downloads.md).

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (io.github.jefersonrl.agrosus.r4)](package.r4.tgz) and [R4B (io.github.jefersonrl.agrosus.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

Este publication inclui o IP abrangido pelas seguintes declarações.

* Classificação conforme a RDC Anvisa nº 294/2019.

* [Classificação Toxicológica de Defensivos Agrícolas](CodeSystem-agrosus-classificacao-toxicologica.md): [AgroSUSAnamnese](Questionnaire-agrosus-anamnese.md) and [AgroSUSClassificacaoToxicologicaVS](ValueSet-agrosus-classificacao-toxicologica.md)


* Este material contém conteúdo do [LOINC](http://loinc.org). LOINC é copyright © 1995-2020, Regenstrief Institute, Inc. e o Logical Observation Identifiers Names and Codes (LOINC) Committee e está disponível sem custo sob a [licença](http://loinc.org/license). LOINC® é uma marca registada dos Estados Unidos da América do Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.1.0/CodeSystem-v3-loinc.html): [AgroSUSExamesLaboratoriaisVS](ValueSet-agrosus-exames-laboratoriais.md), [AgroSUSLaudoLaboratorial](StructureDefinition-agrosus-laudo-laboratorial.md)... Show 9 more, [AgroSUSResultadoLaboratorial](StructureDefinition-agrosus-resultado-laboratorial.md), [AgroSUSResultadosLaboratoriaisVS](ValueSet-agrosus-resultados-laboratoriais.md), [AgroSUSSolicitacaoExame](StructureDefinition-agrosus-solicitacao-exame.md), [DiagnosticReport/agrosus-laudo-hemograma-exemplo](DiagnosticReport-agrosus-laudo-hemograma-exemplo.md), [Observation/agrosus-resultado-hematocrito-exemplo](Observation-agrosus-resultado-hematocrito-exemplo.md), [Observation/agrosus-resultado-hemoglobina-exemplo](Observation-agrosus-resultado-hemoglobina-exemplo.md), [Observation/agrosus-resultado-leucocitos-exemplo](Observation-agrosus-resultado-leucocitos-exemplo.md), [Observation/agrosus-resultado-plaquetas-exemplo](Observation-agrosus-resultado-plaquetas-exemplo.md) and [ServiceRequest/agrosus-solicitacao-hemograma-exemplo](ServiceRequest-agrosus-solicitacao-hemograma-exemplo.md)


* Este material contém conteúdo que é copyright da SNOMED International. Os implementadores destas especificações devem ter a licença apropriada de afiliado da SNOMED CT - para mais informações contacte [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) ou [info@snomed.org](mailto:info@snomed.org).

* [Termos clínicos SNOMED&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [ServiceRequest/agrosus-solicitacao-hemograma-exemplo](ServiceRequest-agrosus-solicitacao-hemograma-exemplo.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.1.0/CodeSystem-ISO3166Part1.html): [AgroSUSACS](StructureDefinition-agrosus-acs.md), [AgroSUSACSRole](StructureDefinition-agrosus-acs-role.md)... Show 77 more, [AgroSUSAnamnese](Questionnaire-agrosus-anamnese.md), [AgroSUSAnamneseResponse](StructureDefinition-agrosus-anamnese-response.md), [AgroSUSArmazenamentoDefensivosCS](CodeSystem-agrosus-armazenamento-defensivos.md), [AgroSUSArmazenamentoEPIVS](ValueSet-agrosus-armazenamento-epi.md), [AgroSUSArmazenamentoRegistrosVS](ValueSet-agrosus-armazenamento-registros.md), [AgroSUSAssistenciaTecnicaCS](CodeSystem-agrosus-assistencia-tecnica.md), [AgroSUSAtendimentoUBS](StructureDefinition-agrosus-atendimento-ubs.md), [AgroSUSAtividadeAgricolaVS](ValueSet-agrosus-atividade-agricola.md), [AgroSUSAuditEvent](StructureDefinition-agrosus-audit-event.md), [AgroSUSAvaliacaoBoasPraticasCS](CodeSystem-agrosus-avaliacao-boas-praticas.md), [AgroSUSAvaliacaoBoasPraticasVS](ValueSet-agrosus-avaliacao-boas-praticas.md), [AgroSUSCapacitacaoCS](CodeSystem-agrosus-capacitacao.md), [AgroSUSCategoriaPlanoCuidadoCS](CodeSystem-agrosus-categoria-plano-cuidado.md), [AgroSUSCategoriaPlanoCuidadoVS](ValueSet-agrosus-categoria-plano-cuidado.md), [AgroSUSClassificacaoToxicologicaCS](CodeSystem-agrosus-classificacao-toxicologica.md), [AgroSUSClassificacaoToxicologicaVS](ValueSet-agrosus-classificacao-toxicologica.md), [AgroSUSCondicaoSaudeReferidaVS](ValueSet-agrosus-condicao-saude-referida.md), [AgroSUSCondicoesSintomasCS](CodeSystem-agrosus-condicoes-sintomas.md), [AgroSUSDestinacaoEmbalagensCS](CodeSystem-agrosus-destinacao-embalagens.md), [AgroSUSDestinacaoEmbalagensNaoDevolvidasVS](ValueSet-agrosus-destinacao-embalagens-nao-devolvidas.md), [AgroSUSDiasAplicacaoMesVS](ValueSet-agrosus-dias-aplicacao-mes.md), [AgroSUSEPICS](CodeSystem-agrosus-epi.md), [AgroSUSEquipamentoAplicacaoVS](ValueSet-agrosus-equipamento-aplicacao.md), [AgroSUSEscolaridadeCS](CodeSystem-agrosus-escolaridade.md), [AgroSUSEscolaridadeVS](ValueSet-agrosus-escolaridade.md), [AgroSUSEstratificacaoRisco](PlanDefinition-AgroSUSEstratificacaoRisco.md), [AgroSUSExamesLaboratoriaisVS](ValueSet-agrosus-exames-laboratoriais.md), [AgroSUSExposicaoCS](CodeSystem-agrosus-exposicao.md), [AgroSUSExposicaoFamiliarCS](CodeSystem-agrosus-exposicao-familiar.md), [AgroSUSFHIR](index.md), [AgroSUSFamiliaresAuxiliamAplicacaoVS](ValueSet-agrosus-familiares-auxiliam-aplicacao.md), [AgroSUSFonteAguaVS](ValueSet-agrosus-fonte-agua.md), [AgroSUSFormacaoResponsavelTecnicoVS](ValueSet-agrosus-formacao-responsavel-tecnico.md), [AgroSUSFrequenciaUsoEPIVS](ValueSet-agrosus-frequencia-uso-epi.md), [AgroSUSHistoricoIntoxicacaoCS](CodeSystem-agrosus-historico-intoxicacao.md), [AgroSUSHorasAplicacaoDiaVS](ValueSet-agrosus-horas-aplicacao-dia.md), [AgroSUSInstituicaoAssistenciaVS](ValueSet-agrosus-instituicao-assistencia.md), [AgroSUSIntoxicacaoLogic](Library-AgroSUSIntoxicacaoLogic.md), [AgroSUSIntoxicacaoPesticida](StructureDefinition-agrosus-intoxicacao-pesticida.md), [AgroSUSIntoxicacaoPesticidaVS](ValueSet-agrosus-intoxicacao-pesticida.md), [AgroSUSLaboratorio](StructureDefinition-agrosus-laboratorio.md), [AgroSUSLaudoLaboratorial](StructureDefinition-agrosus-laudo-laboratorial.md), [AgroSUSLocalArmazenamentoDefensivosVS](ValueSet-agrosus-local-armazenamento-defensivos.md), [AgroSUSMeasureAdesaoPeriodicidade](Measure-AgroSUSMeasureAdesaoPeriodicidade.md), [AgroSUSMeasureAlteradosComConduta](Measure-AgroSUSMeasureAlteradosComConduta.md), [AgroSUSMeasureCoberturaAnamnese](Measure-AgroSUSMeasureCoberturaAnamnese.md), [AgroSUSMeasureCoberturaBasal](Measure-AgroSUSMeasureCoberturaBasal.md), [AgroSUSMeasureCoberturaEPI](Measure-AgroSUSMeasureCoberturaEPI.md), [AgroSUSMesMaiorIntensidadeVS](ValueSet-agrosus-mes-maior-intensidade.md), [AgroSUSMotivoNaoUsoEPIVS](ValueSet-agrosus-motivo-nao-uso-epi.md), [AgroSUSNumeroIntoxicacoesAgudasVS](ValueSet-agrosus-numero-intoxicacoes-agudas.md), [AgroSUSOcupacaoACSVS](ValueSet-agrosus-ocupacao-acs.md), [AgroSUSOcupacaoProfissionalUBSVS](ValueSet-agrosus-ocupacao-profissional-ubs.md), [AgroSUSPatient](StructureDefinition-agrosus-patient.md), [AgroSUSPlanoAcompanhamento](StructureDefinition-agrosus-plano-acompanhamento.md), [AgroSUSPrioridadeAlertaCS](CodeSystem-agrosus-prioridade-alerta.md), [AgroSUSPrioridadeAlertaVS](ValueSet-agrosus-prioridade-alerta.md), [AgroSUSProfissionalUBS](StructureDefinition-agrosus-profissional-ubs.md), [AgroSUSProfissionalUBSRole](StructureDefinition-agrosus-profissional-ubs-role.md), [AgroSUSPropriedadeCS](CodeSystem-agrosus-propriedade.md), [AgroSUSProvenance](StructureDefinition-agrosus-provenance.md), [AgroSUSRastreabilidadeCS](CodeSystem-agrosus-rastreabilidade.md), [AgroSUSResponsavelAplicacaoVS](ValueSet-agrosus-responsavel-aplicacao.md), [AgroSUSResultadoLaboratorial](StructureDefinition-agrosus-resultado-laboratorial.md), [AgroSUSResultadosLaboratoriaisVS](ValueSet-agrosus-resultados-laboratoriais.md), [AgroSUSServerCapabilities](CapabilityStatement-agrosus-server-capabilities.md), [AgroSUSSintomaUltimos30DiasVS](ValueSet-agrosus-sintoma-ultimos-30-dias.md), [AgroSUSSituacaoPosseVS](ValueSet-agrosus-situacao-posse.md), [AgroSUSSolicitacaoExame](StructureDefinition-agrosus-solicitacao-exame.md), [AgroSUSTemasCapacitacaoVS](ValueSet-agrosus-temas-capacitacao.md), [AgroSUSTipoColetaCS](CodeSystem-agrosus-tipo-coleta.md), [AgroSUSTipoColetaVS](ValueSet-agrosus-tipo-coleta.md), [AgroSUSTipoProducaoVS](ValueSet-agrosus-tipo-producao.md), [AgroSUSTransacaoVisita](StructureDefinition-agrosus-transacao-visita.md), [AgroSUSUBS](StructureDefinition-agrosus-ubs.md), [AgroSUSViaExposicaoVS](ValueSet-agrosus-via-exposicao.md) and [AgroSUSVisitaACS](StructureDefinition-agrosus-visita-acs.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.1.0/CodeSystem-v3-ucum.html): [Observation/agrosus-resultado-hematocrito-exemplo](Observation-agrosus-resultado-hematocrito-exemplo.md), [Observation/agrosus-resultado-hemoglobina-exemplo](Observation-agrosus-resultado-hemoglobina-exemplo.md), [Observation/agrosus-resultado-leucocitos-exemplo](Observation-agrosus-resultado-leucocitos-exemplo.md) and [Observation/agrosus-resultado-plaquetas-exemplo](Observation-agrosus-resultado-plaquetas-exemplo.md)


* These codes are excerpted from Digital Imaging and Communications in Medicine (DICOM) Standard, Part 16: Content Mapping Resource, Copyright © 2011 by the National Electrical Manufacturers Association.

* [Audit Event ID](http://terminology.hl7.org/7.1.0/CodeSystem-audit-event-type.html): [AuditEvent/agrosus-auditoria-consulta-dashboard-exemplo](AuditEvent-agrosus-auditoria-consulta-dashboard-exemplo.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Condition Category Codes](http://terminology.hl7.org/7.1.0/CodeSystem-condition-category.html): [Condition/agrosus-intoxicacao-pesticida-suspeita-exemplo](Condition-agrosus-intoxicacao-pesticida-suspeita-exemplo.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.1.0/CodeSystem-condition-clinical.html): [Condition/agrosus-intoxicacao-pesticida-suspeita-exemplo](Condition-agrosus-intoxicacao-pesticida-suspeita-exemplo.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.1.0/CodeSystem-condition-ver-status.html): [Condition/agrosus-intoxicacao-pesticida-suspeita-exemplo](Condition-agrosus-intoxicacao-pesticida-suspeita-exemplo.md)
* [Diagnosis Role](http://terminology.hl7.org/7.1.0/CodeSystem-diagnosis-role.html): [Encounter/agrosus-atendimento-ubs-revisao-exames-exemplo](Encounter-agrosus-atendimento-ubs-revisao-exames-exemplo.md)
* [LibraryType](http://terminology.hl7.org/7.1.0/CodeSystem-library-type.html): [AgroSUSIntoxicacaoLogic](Library-AgroSUSIntoxicacaoLogic.md)
* [Measure Population Type](http://terminology.hl7.org/7.1.0/CodeSystem-measure-population.html): [AgroSUSMeasureAdesaoPeriodicidade](Measure-AgroSUSMeasureAdesaoPeriodicidade.md), [AgroSUSMeasureAlteradosComConduta](Measure-AgroSUSMeasureAlteradosComConduta.md), [AgroSUSMeasureCoberturaAnamnese](Measure-AgroSUSMeasureCoberturaAnamnese.md), [AgroSUSMeasureCoberturaBasal](Measure-AgroSUSMeasureCoberturaBasal.md) and [AgroSUSMeasureCoberturaEPI](Measure-AgroSUSMeasureCoberturaEPI.md)
* [Measure Scoring](http://terminology.hl7.org/7.1.0/CodeSystem-measure-scoring.html): [AgroSUSMeasureAdesaoPeriodicidade](Measure-AgroSUSMeasureAdesaoPeriodicidade.md), [AgroSUSMeasureAlteradosComConduta](Measure-AgroSUSMeasureAlteradosComConduta.md), [AgroSUSMeasureCoberturaAnamnese](Measure-AgroSUSMeasureCoberturaAnamnese.md), [AgroSUSMeasureCoberturaBasal](Measure-AgroSUSMeasureCoberturaBasal.md) and [AgroSUSMeasureCoberturaEPI](Measure-AgroSUSMeasureCoberturaEPI.md)
* [Observation Category Codes](http://terminology.hl7.org/7.1.0/CodeSystem-observation-category.html): [Observation/agrosus-resultado-hematocrito-exemplo](Observation-agrosus-resultado-hematocrito-exemplo.md), [Observation/agrosus-resultado-hemoglobina-exemplo](Observation-agrosus-resultado-hemoglobina-exemplo.md), [Observation/agrosus-resultado-leucocitos-exemplo](Observation-agrosus-resultado-leucocitos-exemplo.md) and [Observation/agrosus-resultado-plaquetas-exemplo](Observation-agrosus-resultado-plaquetas-exemplo.md)
* [PlanDefinitionType](http://terminology.hl7.org/7.1.0/CodeSystem-plan-definition-type.html): [AgroSUSEstratificacaoRisco](PlanDefinition-AgroSUSEstratificacaoRisco.md)
* [Provenance participant type](http://terminology.hl7.org/7.1.0/CodeSystem-provenance-participant-type.html): [Bundle/agrosus-transacao-visita-exemplo](Bundle-agrosus-transacao-visita-exemplo.md), [Provenance/agrosus-provenance-anamnese-exemplo](Provenance-agrosus-provenance-anamnese-exemplo.md) and [Provenance/agrosus-provenance-plano-acompanhamento-exemplo](Provenance-agrosus-provenance-plano-acompanhamento-exemplo.md)
* [diagnosticServiceSectionId](http://terminology.hl7.org/7.1.0/CodeSystem-v2-0074.html): [DiagnosticReport/agrosus-laudo-hemograma-exemplo](DiagnosticReport-agrosus-laudo-hemograma-exemplo.md)
* [identifierType](http://terminology.hl7.org/7.1.0/CodeSystem-v2-0203.html): [Bundle/agrosus-transacao-visita-exemplo](Bundle-agrosus-transacao-visita-exemplo.md), [Laboratório Municipal de Referência — Exemplo AgroSUS](Organization-agrosus-laboratorio-exemplo.md)... Show 6 more, [Patient/agrosus-patient-example](Patient-agrosus-patient-example.md), [Practitioner/agrosus-acs-exemplo](Practitioner-agrosus-acs-exemplo.md), [Practitioner/agrosus-profissional-enfermeiro-exemplo](Practitioner-agrosus-profissional-enfermeiro-exemplo.md), [Practitioner/agrosus-profissional-medico-exemplo](Practitioner-agrosus-profissional-medico-exemplo.md), [Practitioner/agrosus-profissional-tecnico-enfermagem-exemplo](Practitioner-agrosus-profissional-tecnico-enfermagem-exemplo.md) and [UBS Jardim Esperança — Exemplo AgroSUS](Organization-agrosus-ubs-exemplo.md)
* [ActCode](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActCode.html): [Bundle/agrosus-transacao-visita-exemplo](Bundle-agrosus-transacao-visita-exemplo.md), [Encounter/agrosus-atendimento-ubs-avaliacao-exemplo](Encounter-agrosus-atendimento-ubs-avaliacao-exemplo.md), [Encounter/agrosus-atendimento-ubs-revisao-exames-exemplo](Encounter-agrosus-atendimento-ubs-revisao-exames-exemplo.md) and [Encounter/agrosus-visita-acs-exemplo](Encounter-agrosus-visita-acs-exemplo.md)
* [ActPriority](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActPriority.html): [Bundle/agrosus-transacao-visita-exemplo](Bundle-agrosus-transacao-visita-exemplo.md), [Encounter/agrosus-atendimento-ubs-avaliacao-exemplo](Encounter-agrosus-atendimento-ubs-avaliacao-exemplo.md), [Encounter/agrosus-atendimento-ubs-revisao-exames-exemplo](Encounter-agrosus-atendimento-ubs-revisao-exames-exemplo.md) and [Encounter/agrosus-visita-acs-exemplo](Encounter-agrosus-visita-acs-exemplo.md)
* [ActReason](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActReason.html): [AuditEvent/agrosus-auditoria-consulta-dashboard-exemplo](AuditEvent-agrosus-auditoria-consulta-dashboard-exemplo.md), [Bundle/agrosus-transacao-visita-exemplo](Bundle-agrosus-transacao-visita-exemplo.md), [Provenance/agrosus-provenance-anamnese-exemplo](Provenance-agrosus-provenance-anamnese-exemplo.md) and [Provenance/agrosus-provenance-plano-acompanhamento-exemplo](Provenance-agrosus-provenance-plano-acompanhamento-exemplo.md)
* [DataOperation](http://terminology.hl7.org/7.1.0/CodeSystem-v3-DataOperation.html): [Bundle/agrosus-transacao-visita-exemplo](Bundle-agrosus-transacao-visita-exemplo.md), [Provenance/agrosus-provenance-anamnese-exemplo](Provenance-agrosus-provenance-anamnese-exemplo.md) and [Provenance/agrosus-provenance-plano-acompanhamento-exemplo](Provenance-agrosus-provenance-plano-acompanhamento-exemplo.md)
* [ObservationInterpretation](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ObservationInterpretation.html): [Observation/agrosus-resultado-hematocrito-exemplo](Observation-agrosus-resultado-hematocrito-exemplo.md), [Observation/agrosus-resultado-hemoglobina-exemplo](Observation-agrosus-resultado-hemoglobina-exemplo.md), [Observation/agrosus-resultado-leucocitos-exemplo](Observation-agrosus-resultado-leucocitos-exemplo.md) and [Observation/agrosus-resultado-plaquetas-exemplo](Observation-agrosus-resultado-plaquetas-exemplo.md)
* [ParticipationType](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ParticipationType.html): [Bundle/agrosus-transacao-visita-exemplo](Bundle-agrosus-transacao-visita-exemplo.md), [Encounter/agrosus-atendimento-ubs-avaliacao-exemplo](Encounter-agrosus-atendimento-ubs-avaliacao-exemplo.md), [Encounter/agrosus-atendimento-ubs-revisao-exames-exemplo](Encounter-agrosus-atendimento-ubs-revisao-exames-exemplo.md) and [Encounter/agrosus-visita-acs-exemplo](Encounter-agrosus-visita-acs-exemplo.md)


