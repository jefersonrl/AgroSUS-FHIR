# io.github.jefersonrl.agrosus#0.1.0: Projeto mareIA: módulo AgroSUS para telemonitoramento e apoio à identificação precoce de intoxicações por uso de defensivos agrícolas

## Pages

* [Início](index.md)
* [7. Indicadores de Programa](l2-indicators.md)
* [1. Intervenções e Recomendações](l2-interventions.md)
* [3. Cenários de Uso](l2-user-scenarios.md)
* [Downloads](downloads.md)
* [8. Requisitos Funcionais e Não-Funcionais](l2-requirements.md)
* [6. Lógica de Suporte à Decisão](l2-decision-logic.md)
* [4. Processos de Negócio e Workflows](l2-business-process.md)
* [5. Elementos de Dados (Dicionário)](l2-data-dictionary.md)
* [2. Personas Genéricas](l2-personas.md)
* [9. Cenários de Teste](l2-test-scenarios.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Armazenamento de defensivos agrícolas AgroSUS](CodeSystem-agrosus-armazenamento-defensivos.md)
* [Assistência Técnica AgroSUS](CodeSystem-agrosus-assistencia-tecnica.md)
* [Avaliação de boas práticas agrícolas AgroSUS](CodeSystem-agrosus-avaliacao-boas-praticas.md)
* [Temas de Capacitação AgroSUS](CodeSystem-agrosus-capacitacao.md)
* [Categorias de Plano de Cuidado AgroSUS](CodeSystem-agrosus-categoria-plano-cuidado.md)
* [Classificação Toxicológica de Defensivos Agrícolas](CodeSystem-agrosus-classificacao-toxicologica.md)
* [Condições de saúde e sintomas AgroSUS](CodeSystem-agrosus-condicoes-sintomas.md)
* [Destinação de embalagens vazias AgroSUS](CodeSystem-agrosus-destinacao-embalagens.md)
* [Terminologia de equipamentos de proteção individual AgroSUS](CodeSystem-agrosus-epi.md)
* [Escolaridade AgroSUS](CodeSystem-agrosus-escolaridade.md)
* [Exposição familiar AgroSUS](CodeSystem-agrosus-exposicao-familiar.md)
* [Terminologia de exposição ocupacional AgroSUS](CodeSystem-agrosus-exposicao.md)
* [Histórico de intoxicação AgroSUS](CodeSystem-agrosus-historico-intoxicacao.md)
* [Prioridade de Alerta AgroSUS](CodeSystem-agrosus-prioridade-alerta.md)
* [Terminologia da Propriedade Rural AgroSUS](CodeSystem-agrosus-propriedade.md)
* [Rastreabilidade das aplicações AgroSUS](CodeSystem-agrosus-rastreabilidade.md)
* [Tipos de Coleta AgroSUS](CodeSystem-agrosus-tipo-coleta.md)

### ValueSets

* [Local de armazenamento dos EPIs](ValueSet-agrosus-armazenamento-epi.md)
* [Formas de armazenamento dos registros](ValueSet-agrosus-armazenamento-registros.md)
* [Principal Atividade Agrícola](ValueSet-agrosus-atividade-agricola.md)
* [Respostas dos indicadores de boas práticas](ValueSet-agrosus-avaliacao-boas-praticas.md)
* [Categorias de Plano de Cuidado AgroSUS](ValueSet-agrosus-categoria-plano-cuidado.md)
* [Classificação Toxicológica de Defensivos Agrícolas](ValueSet-agrosus-classificacao-toxicologica.md)
* [Condições de saúde referidas](ValueSet-agrosus-condicao-saude-referida.md)
* [Destinação de embalagens não devolvidas](ValueSet-agrosus-destinacao-embalagens-nao-devolvidas.md)
* [Dias de aplicação por mês](ValueSet-agrosus-dias-aplicacao-mes.md)
* [Equipamentos utilizados na aplicação](ValueSet-agrosus-equipamento-aplicacao.md)
* [Escolaridade AgroSUS](ValueSet-agrosus-escolaridade.md)
* [Exames Laboratoriais AgroSUS](ValueSet-agrosus-exames-laboratoriais.md)
* [Familiares que auxiliam na aplicação](ValueSet-agrosus-familiares-auxiliam-aplicacao.md)
* [Fonte de Água da Propriedade](ValueSet-agrosus-fonte-agua.md)
* [Formação do Responsável Técnico](ValueSet-agrosus-formacao-responsavel-tecnico.md)
* [Frequência de utilização de EPI](ValueSet-agrosus-frequencia-uso-epi.md)
* [Horas de aplicação por dia](ValueSet-agrosus-horas-aplicacao-dia.md)
* [Instituição de Assistência Técnica](ValueSet-agrosus-instituicao-assistencia.md)
* [Intoxicação por pesticidas AgroSUS](ValueSet-agrosus-intoxicacao-pesticida.md)
* [Local de armazenamento dos defensivos agrícolas](ValueSet-agrosus-local-armazenamento-defensivos.md)
* [Meses de maior intensidade de uso](ValueSet-agrosus-mes-maior-intensidade.md)
* [Motivos de não utilização de EPI](ValueSet-agrosus-motivo-nao-uso-epi.md)
* [Número de intoxicações agudas anteriores](ValueSet-agrosus-numero-intoxicacoes-agudas.md)
* [Ocupações permitidas para o ACS no AgroSUS](ValueSet-agrosus-ocupacao-acs.md)
* [Ocupações dos profissionais assistenciais da UBS](ValueSet-agrosus-ocupacao-profissional-ubs.md)
* [Prioridade de Alerta AgroSUS](ValueSet-agrosus-prioridade-alerta.md)
* [Responsável pela aplicação](ValueSet-agrosus-responsavel-aplicacao.md)
* [Resultados Laboratoriais AgroSUS](ValueSet-agrosus-resultados-laboratoriais.md)
* [Sinais e sintomas dos últimos 30 dias](ValueSet-agrosus-sintoma-ultimos-30-dias.md)
* [Situação de Posse da Terra](ValueSet-agrosus-situacao-posse.md)
* [Temas de Capacitação AgroSUS](ValueSet-agrosus-temas-capacitacao.md)
* [Tipos de Coleta AgroSUS](ValueSet-agrosus-tipo-coleta.md)
* [Tipo de Produção Agrícola](ValueSet-agrosus-tipo-producao.md)
* [Vias de exposição](ValueSet-agrosus-via-exposicao.md)

### Resource Profiles

* [Função do ACS no AgroSUS](StructureDefinition-agrosus-acs-role.md)
* [Agente Comunitário de Saúde AgroSUS](StructureDefinition-agrosus-acs.md)
* [Resposta da Anamnese AgroSUS](StructureDefinition-agrosus-anamnese-response.md)
* [Atendimento Clínico da UBS AgroSUS](StructureDefinition-agrosus-atendimento-ubs.md)
* [Evento de Auditoria AgroSUS](StructureDefinition-agrosus-audit-event.md)
* [Suspeita ou Confirmação de Intoxicação por Pesticida AgroSUS](StructureDefinition-agrosus-intoxicacao-pesticida.md)
* [Laboratório AgroSUS](StructureDefinition-agrosus-laboratorio.md)
* [Laudo Laboratorial AgroSUS](StructureDefinition-agrosus-laudo-laboratorial.md)
* [Paciente AgroSUS](StructureDefinition-agrosus-patient.md)
* [Plano de Acompanhamento AgroSUS](StructureDefinition-agrosus-plano-acompanhamento.md)
* [Função do Profissional Assistencial da UBS AgroSUS](StructureDefinition-agrosus-profissional-ubs-role.md)
* [Profissional Assistencial da UBS AgroSUS](StructureDefinition-agrosus-profissional-ubs.md)
* [Proveniência dos Registros AgroSUS](StructureDefinition-agrosus-provenance.md)
* [Resultado Laboratorial AgroSUS](StructureDefinition-agrosus-resultado-laboratorial.md)
* [Solicitação de Exame AgroSUS](StructureDefinition-agrosus-solicitacao-exame.md)
* [Transação da Visita do ACS AgroSUS](StructureDefinition-agrosus-transacao-visita.md)
* [Unidade Básica de Saúde AgroSUS](StructureDefinition-agrosus-ubs.md)
* [Visita do ACS AgroSUS](StructureDefinition-agrosus-visita-acs.md)

### CapabilityStatements

* [Requisitos de capacidade do servidor AgroSUS](CapabilityStatement-agrosus-server-capabilities.md)

### ImplementationGuides

* [Projeto mareIA: módulo AgroSUS para telemonitoramento e apoio à identificação precoce de intoxicações por uso de defensivos agrícolas](index.md)

### Libraries

* [Lógica de decisão da vigilância de intoxicação por defensivos agrícolas (AgroSUS)](Library-AgroSUSIntoxicacaoLogic.md)

### Measures

* [Adesão à periodicidade semestral do monitoramento biológico (AgroSUS)](Measure-AgroSUSMeasureAdesaoPeriodicidade.md)
* [Proporção de resultados alterados de colinesterase com conduta registrada (AgroSUS)](Measure-AgroSUSMeasureAlteradosComConduta.md)
* [Cobertura da anamnese ocupacional AgroSUS](Measure-AgroSUSMeasureCoberturaAnamnese.md)
* [Cobertura do exame basal de colinesterase (AgroSUS)](Measure-AgroSUSMeasureCoberturaBasal.md)
* [Cobertura de uso adequado de EPI (AgroSUS)](Measure-AgroSUSMeasureCoberturaEPI.md)

### PlanDefinitions

* [AgroSUS — Vigilância biológica, periodicidade e alertas de intoxicação por defensivos](PlanDefinition-AgroSUSEstratificacaoRisco.md)

### Questionnaires

* [Formulário de Anamnese Ocupacional e Ambiental AgroSUS](Questionnaire-agrosus-anamnese.md)

### Examples

* [agrosus-auditoria-consulta-dashboard-exemplo (AuditEvent)](AuditEvent-agrosus-auditoria-consulta-dashboard-exemplo.md)
* [agrosus-transacao-visita-exemplo (Bundle)](Bundle-agrosus-transacao-visita-exemplo.md)
* [Acompanhamento clínico e ocupacional AgroSUS (CarePlan)](CarePlan-agrosus-plano-acompanhamento-exemplo.md)
* [agrosus-intoxicacao-pesticida-suspeita-exemplo (Condition)](Condition-agrosus-intoxicacao-pesticida-suspeita-exemplo.md)
* [agrosus-laudo-hemograma-exemplo (DiagnosticReport)](DiagnosticReport-agrosus-laudo-hemograma-exemplo.md)
* [agrosus-atendimento-ubs-avaliacao-exemplo (Encounter)](Encounter-agrosus-atendimento-ubs-avaliacao-exemplo.md)
* [agrosus-atendimento-ubs-revisao-exames-exemplo (Encounter)](Encounter-agrosus-atendimento-ubs-revisao-exames-exemplo.md)
* [agrosus-visita-acs-exemplo (Encounter)](Encounter-agrosus-visita-acs-exemplo.md)
* [agrosus-resultado-colinesterase-alterada-exemplo (Observation)](Observation-agrosus-resultado-colinesterase-alterada-exemplo.md)
* [agrosus-resultado-colinesterase-basal-exemplo (Observation)](Observation-agrosus-resultado-colinesterase-basal-exemplo.md)
* [agrosus-resultado-colinesterase-normal-exemplo (Observation)](Observation-agrosus-resultado-colinesterase-normal-exemplo.md)
* [agrosus-resultado-colinesterase-precaucao-exemplo (Observation)](Observation-agrosus-resultado-colinesterase-precaucao-exemplo.md)
* [agrosus-resultado-hematocrito-exemplo (Observation)](Observation-agrosus-resultado-hematocrito-exemplo.md)
* [agrosus-resultado-hemoglobina-exemplo (Observation)](Observation-agrosus-resultado-hemoglobina-exemplo.md)
* [agrosus-resultado-leucocitos-exemplo (Observation)](Observation-agrosus-resultado-leucocitos-exemplo.md)
* [agrosus-resultado-plaquetas-exemplo (Observation)](Observation-agrosus-resultado-plaquetas-exemplo.md)
* [Laboratório Municipal de Referência — Exemplo AgroSUS (Organization)](Organization-agrosus-laboratorio-exemplo.md)
* [UBS Jardim Esperança — Exemplo AgroSUS (Organization)](Organization-agrosus-ubs-exemplo.md)
* [agrosus-patient-example (Patient)](Patient-agrosus-patient-example.md)
* [agrosus-acs-exemplo (Practitioner)](Practitioner-agrosus-acs-exemplo.md)
* [agrosus-profissional-enfermeiro-exemplo (Practitioner)](Practitioner-agrosus-profissional-enfermeiro-exemplo.md)
* [agrosus-profissional-medico-exemplo (Practitioner)](Practitioner-agrosus-profissional-medico-exemplo.md)
* [agrosus-profissional-tecnico-enfermagem-exemplo (Practitioner)](Practitioner-agrosus-profissional-tecnico-enfermagem-exemplo.md)
* [agrosus-acs-role-exemplo (PractitionerRole)](PractitionerRole-agrosus-acs-role-exemplo.md)
* [agrosus-profissional-enfermeiro-role-exemplo (PractitionerRole)](PractitionerRole-agrosus-profissional-enfermeiro-role-exemplo.md)
* [agrosus-profissional-medico-role-exemplo (PractitionerRole)](PractitionerRole-agrosus-profissional-medico-role-exemplo.md)
* [agrosus-profissional-tecnico-enfermagem-role-exemplo (PractitionerRole)](PractitionerRole-agrosus-profissional-tecnico-enfermagem-role-exemplo.md)
* [agrosus-provenance-anamnese-exemplo (Provenance)](Provenance-agrosus-provenance-anamnese-exemplo.md)
* [agrosus-provenance-plano-acompanhamento-exemplo (Provenance)](Provenance-agrosus-provenance-plano-acompanhamento-exemplo.md)
* [agrosus-anamnese-response-example (QuestionnaireResponse)](QuestionnaireResponse-agrosus-anamnese-response-example.md)
* [agrosus-solicitacao-colinesterase-basal-exemplo (ServiceRequest)](ServiceRequest-agrosus-solicitacao-colinesterase-basal-exemplo.md)
* [agrosus-solicitacao-colinesterase-retestagem-exemplo (ServiceRequest)](ServiceRequest-agrosus-solicitacao-colinesterase-retestagem-exemplo.md)
* [agrosus-solicitacao-colinesterase-semestral-2026-exemplo (ServiceRequest)](ServiceRequest-agrosus-solicitacao-colinesterase-semestral-2026-exemplo.md)
* [agrosus-solicitacao-colinesterase-semestral-2027-01-exemplo (ServiceRequest)](ServiceRequest-agrosus-solicitacao-colinesterase-semestral-2027-01-exemplo.md)
* [agrosus-solicitacao-colinesterase-semestral-2027-07-exemplo (ServiceRequest)](ServiceRequest-agrosus-solicitacao-colinesterase-semestral-2027-07-exemplo.md)
* [agrosus-solicitacao-hemograma-exemplo (ServiceRequest)](ServiceRequest-agrosus-solicitacao-hemograma-exemplo.md)
